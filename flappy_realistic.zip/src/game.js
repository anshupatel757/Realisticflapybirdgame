// Realistic(ish) Flappy Bird — Canvas + WebAudio
// Controls: Space (PC) / Tap (Mobile).
// Sounds: Procedural wind + bird chirp + flap thump (no external files).

(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const DPR = Math.max(1, Math.min(2, (window.devicePixelRatio || 1)));
  let W = 0, H = 0;

  function resize() {
    W = Math.floor(window.innerWidth);
    H = Math.floor(window.innerHeight);
    canvas.style.width = W + 'px';
    canvas.style.height = H + 'px';
    canvas.width = Math.floor(W * DPR);
    canvas.height = Math.floor(H * DPR);
    ctx.setTransform(DPR,0,0,DPR,0,0);
  }
  window.addEventListener('resize', resize);
  resize();

  // Load assets (SVGs)
  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = src;
    });
  }

  const assets = {
    bird: [ 'assets/bird1.svg', 'assets/bird2.svg' ],
    clouds: [ 'assets/cloud1.svg', 'assets/cloud2.svg' ]
  };

  // WebAudio: wind loop + bird chirp + flap
  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  const masterGain = audioCtx.createGain();
  masterGain.gain.value = 0.8;
  masterGain.connect(audioCtx.destination);

  function makeWind() {
    const bufferSize = 2 * audioCtx.sampleRate;
    const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;

    const noise = audioCtx.createBufferSource();
    noise.buffer = noiseBuffer;
    noise.loop = true;

    const filter = audioCtx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 800;

    const gain = audioCtx.createGain();
    gain.gain.value = 0.05; // subtle

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(masterGain);
    noise.start();

    // gentle amplitude LFO
    const lfo = audioCtx.createOscillator();
    const lfoGain = audioCtx.createGain();
    lfo.frequency.value = 0.15;
    lfoGain.gain.value = 0.04;
    lfo.connect(lfoGain);
    lfoGain.connect(gain.gain);
    lfo.start();

    return { noise, filter, gain, lfo, lfoGain };
  }

  function birdChirp() {
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = 'triangle';
    o.frequency.value = 1200;
    g.gain.value = 0.0;
    o.connect(g); g.connect(masterGain);
    o.start();
    const now = audioCtx.currentTime;
    o.frequency.setValueAtTime(1500, now);
    o.frequency.exponentialRampToValueAtTime(2200, now + 0.08);
    g.gain.setValueAtTime(0.0, now);
    g.gain.linearRampToValueAtTime(0.25, now + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);
    o.stop(now + 0.18);
  }

  function flapThump() {
    const o = audioCtx.createOscillator();
    const n = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = 'sine'; n.type = 'square';
    o.frequency.value = 200; n.frequency.value = 120;
    g.gain.value = 0.0;
    o.connect(g); n.connect(g); g.connect(masterGain);
    const now = audioCtx.currentTime;
    o.frequency.exponentialRampToValueAtTime(90, now + 0.08);
    n.frequency.exponentialRampToValueAtTime(60, now + 0.08);
    g.gain.linearRampToValueAtTime(0.35, now + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
    o.stop(now + 0.15); n.stop(now + 0.15);
  }

  let wind;
  let audioStarted = false;
  function ensureAudio() {
    if (audioStarted) return;
    audioStarted = true;
    audioCtx.resume();
    wind = makeWind();
    // occasional chirps
    setInterval(() => { if (!game.over && Math.random() < 0.2) birdChirp(); }, 1800);
  }

  // Input
  let inputQueued = false;
  function flap() {
    ensureAudio();
    game.bird.vy = -game.config.flapStrength;
    game.bird.rot = -0.4;
    flapThump();
  }

  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space') {
      e.preventDefault();
      inputQueued = true;
    }
  }, { passive: false });

  window.addEventListener('touchstart', (e) => {
    e.preventDefault();
    inputQueued = true;
  }, { passive: false });

  // Game state
  const game = {
    over: false,
    started: false,
    score: 0,
    hiscore: parseInt(localStorage.getItem('rb_hiscore') || '0', 10),
    skyHue: 205,
    config: {
      gravity: 0.42,
      flapStrength: 7.4,
      pipeGap: 160,
      pipeW: 84,
      pipeSpeed: 3.3,
      spawnEvery: 1500,
      groundH: 80
    },
    bird: { x: 140, y: 260, vy: 0, rot: 0, frame: 0, t: 0 },
    pipes: [],
    clouds: []
  };

  // Clouds
  class Cloud {
    constructor(img) {
      this.img = img;
      this.reset(true);
    }
    reset(initial=false) {
      this.x = initial ? (Math.random()*W) : (W + Math.random()*W*0.5);
      this.y = Math.random()*H*0.5 + 20;
      this.scale = 0.5 + Math.random()*0.9;
      this.speed = 0.3 + Math.random()*0.7;
      this.alpha = 0.6 + Math.random()*0.3;
    }
    update(dt) {
      this.x -= this.speed * dt * 0.06 * 60;
      if (this.x < -this.img.width*this.scale) this.reset(false);
    }
    draw(ctx) {
      ctx.save();
      ctx.globalAlpha = this.alpha;
      ctx.drawImage(this.img, this.x, this.y, this.img.width*this.scale, this.img.height*this.scale);
      ctx.restore();
    }
  }

  // Pipes
  class PipePair {
    constructor(x, gapY) {
      this.x = x;
      this.gapY = gapY;
      this.passed = false;
    }
    update(dt) {
      this.x -= game.config.pipeSpeed * dt * 0.06 * 60;
    }
    offscreen() { return this.x + game.config.pipeW < -10; }
    collides(bx, by, br) {
      const w = game.config.pipeW;
      const gap = game.config.pipeGap;
      // top pipe rect: x..x+w, 0..gapY
      // bottom pipe rect: x..x+w, gapY+gap..H-groundH
      function circleRectCollision(cx, cy, r, rx, ry, rw, rh) {
        const closestX = Math.max(rx, Math.min(cx, rx+rw));
        const closestY = Math.max(ry, Math.min(cy, ry+rh));
        const dx = cx - closestX, dy = cy - closestY;
        return (dx*dx + dy*dy) < (r*r);
      }
      if (circleRectCollision(bx, by, br, this.x, 0, w, this.gapY)) return true;
      if (circleRectCollision(bx, by, br, this.x, this.gapY + gap, w, H - game.config.groundH - (this.gapY + gap))) return true;
      return false;
    }
    draw(ctx) {
      const w = game.config.pipeW;
      const gap = game.config.pipeGap;
      ctx.fillStyle = '#14532d';
      ctx.strokeStyle = '#064e3b';
      ctx.lineWidth = 6;

      // top
      ctx.beginPath();
      ctx.rect(this.x, 0, w, this.gapY);
      ctx.fill();
      ctx.stroke();

      // bottom
      ctx.beginPath();
      ctx.rect(this.x, this.gapY + gap, w, H - game.config.groundH - (this.gapY + gap));
      ctx.fill();
      ctx.stroke();

      // rims
      ctx.fillStyle = '#166534';
      ctx.fillRect(this.x - 6, this.gapY - 22, w + 12, 22);
      ctx.fillRect(this.x - 6, this.gapY + gap, w + 12, 22);
    }
  }

  // Overlay UI
  const overlay = document.getElementById('overlay');
  const restartBtn = document.getElementById('restartBtn');
  const scoreEl = document.getElementById('score');
  const hiscoreEl = document.getElementById('hiscore');
  const finalScoreEl = document.getElementById('finalScore');
  const bestScoreEl = document.getElementById('bestScore');

  function showOverlay() {
    finalScoreEl.textContent = game.score;
    bestScoreEl.textContent = game.hiscore;
    overlay.classList.remove('hidden');
  }
  function hideOverlay() {
    overlay.classList.add('hidden');
  }

  restartBtn.addEventListener('click', () => start(true));

  function start(restart=false) {
    hideOverlay();
    game.over = false;
    game.started = false;
    game.score = 0;
    game.bird = { x: 140, y: H*0.4, vy: 0, rot: 0, frame: 0, t: 0 };
    game.pipes = [];
    // position clouds
    game.clouds.forEach(c => c.reset(true));
    lastSpawn = 0;
  }

  // Background sky gradient
  function drawSky(ctx) {
    const g = ctx.createLinearGradient(0, 0, 0, H);
    // dawn/dusk vibe
    g.addColorStop(0, '#60a5fa'); // sky blue
    g.addColorStop(1, '#93c5fd');
    ctx.fillStyle = g;
    ctx.fillRect(0,0,W,H);
  }

  // Ground
  function drawGround(ctx) {
    const y = H - game.config.groundH;
    ctx.fillStyle = '#065f46';
    ctx.fillRect(0, y, W, game.config.groundH);
    // stripes
    ctx.fillStyle = '#047857';
    for (let i=0;i<W;i+=40) ctx.fillRect(i, y, 20, 8);
  }

  // Main loop
  let last = performance.now();
  let lastSpawn = 0;
  let birdImgs = [];
  let cloudImgs = [];

  Promise.all(assets.bird.map(loadImage)).then(imgs => birdImgs = imgs);
  Promise.all(assets.clouds.map(loadImage)).then(imgs => {
    cloudImgs = imgs;
    // create clouds
    for (let i=0;i<6;i++) {
      game.clouds.push(new Cloud(cloudImgs[i%cloudImgs.length]));
    }
  });

  function update(dt) {
    // start on first input
    if (!game.started && inputQueued) {
      inputQueued = false; flap();
      game.started = true;
    }

    // queued flap during play
    if (inputQueued && !game.over) {
      inputQueued = false; flap();
    }

    // bird anim
    game.bird.t += dt;
    if (game.bird.t > 100) { game.bird.t = 0; game.bird.frame = (game.bird.frame+1)%2; }

    // clouds
    game.clouds.forEach(c => c.update(dt));

    if (!game.started) return;

    // pipes
    lastSpawn += dt;
    if (lastSpawn > game.config.spawnEvery) {
      lastSpawn = 0;
      const margin = 60;
      const gapCenter = Math.random() * (H - game.config.groundH - game.config.pipeGap - margin*2) + margin + game.config.pipeGap/2;
      game.pipes.push(new PipePair(W + 40, gapCenter - game.config.pipeGap/2));
    }

    // update pipes
    for (const p of game.pipes) p.update(dt);
    // remove offscreen
    game.pipes = game.pipes.filter(p => !p.offscreen());

    // physics
    game.bird.vy += game.config.gravity * (dt/16.67);
    game.bird.y += game.bird.vy * (dt/16.67);

    // clamp + ground collision
    const groundY = H - game.config.groundH;
    const radius = 22;
    if (game.bird.y + radius > groundY) {
      game.bird.y = groundY - radius;
      die();
    }
    if (game.bird.y - radius < 0) {
      game.bird.y = radius;
      game.bird.vy = 0;
    }

    // pipe collision + scoring
    for (const p of game.pipes) {
      if (!p.passed && p.x + game.config.pipeW < game.bird.x - radius) {
        p.passed = true;
        game.score++;
        scoreEl.textContent = game.score;
        if (game.score > game.hiscore) {
          game.hiscore = game.score;
          localStorage.setItem('rb_hiscore', String(game.hiscore));
          hiscoreEl.textContent = game.hiscore;
        }
      }
      if (p.collides(game.bird.x, game.bird.y, radius)) {
        die();
      }
    }

    // bird rotation
    game.bird.rot = Math.min(1.0, Math.max(-0.9, game.bird.rot + 0.06));
  }

  function die() {
    if (game.over) return;
    game.over = true;
    setTimeout(() => { showOverlay(); }, 250);
  }

  function draw() {
    drawSky(ctx);
    // clouds
    game.clouds.forEach(c => c.draw(ctx));

    // pipes
    game.pipes.forEach(p => p.draw(ctx));

    // ground
    drawGround(ctx);

    // bird
    const img = birdImgs.length ? birdImgs[game.bird.frame] : null;
    ctx.save();
    ctx.translate(game.bird.x, game.bird.y);
    ctx.rotate(game.bird.rot);
    if (img) {
      const scale = 0.8;
      ctx.drawImage(img, -img.width*0.5*scale, -img.height*0.5*scale, img.width*scale, img.height*scale);
    } else {
      // fallback circle
      ctx.fillStyle = '#111827';
      ctx.beginPath(); ctx.arc(0,0,22,0,Math.PI*2); ctx.fill();
    }
    ctx.restore();
  }

  function loop(now) {
    const dt = Math.min(34, now - last); last = now;
    if (!game.over) update(dt);
    draw();
    requestAnimationFrame(loop);
  }

  // initialize hiscore
  hiscoreEl.textContent = game.hiscore;

  requestAnimationFrame(loop);
})();
